
.. _`pip cache`:

pip cache
---------


Usage
*****

.. tab:: Unix/macOS

   .. pip-command-usage:: cache "python -m pip"

.. tab:: Windows

   .. pip-command-usage:: cache "py -m pip"

Description
***********

.. pip-command-description:: cache

Options
*******

.. pip-command-options:: cache
